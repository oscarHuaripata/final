﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinancistoCloneWeb.Services
{
    public class DriveFileService : IFileService
    {
        public object Download(object file)
        {
            throw new NotImplementedException();
        }

        public void Upload(IFormFile file)
        {
            // aca va el codigo
        }
    }
}
