﻿namespace FinancistoCloneWeb.Models
{
    public class Etiqueta
    {
        public int    EtiquetaId { get; set; }
        public string Nombre { get; set; }
    }
}
